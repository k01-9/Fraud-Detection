#!/usr/bin/env python3
"""
setup.py — One-click project setup for VS Code
=====================================================
Run this FIRST before anything else:

    python setup.py

What it does:
  1. Checks your Python version (needs 3.9+)
  2. Creates a virtual environment (venv/)
  3. Installs all requirements
  4. Downloads the spaCy language model
  5. Creates necessary folders (data/, models/, logs/)
  6. Creates a .env file with defaults
  7. Prints the exact command to start the server
"""

import os
import sys
import subprocess
import platform

# ── ANSI Colours ─────────────────────────────────────────────
GREEN  = "\033[92m"
YELLOW = "\033[93m"
RED    = "\033[91m"
BLUE   = "\033[94m"
RESET  = "\033[0m"
BOLD   = "\033[1m"

def log(msg, colour=GREEN):
    print(f"{colour}✓ {msg}{RESET}")

def warn(msg):
    print(f"{YELLOW}⚠  {msg}{RESET}")

def error(msg):
    print(f"{RED}✗  {msg}{RESET}")

def info(msg):
    print(f"{BLUE}→  {msg}{RESET}")

def header(msg):
    print(f"\n{BOLD}{BLUE}{'='*60}{RESET}")
    print(f"{BOLD}{BLUE}  {msg}{RESET}")
    print(f"{BOLD}{BLUE}{'='*60}{RESET}\n")


def check_python_version():
    header("Step 1: Checking Python Version")
    v = sys.version_info
    if v.major < 3 or (v.major == 3 and v.minor < 9):
        error(f"Python 3.9+ is required. You have {v.major}.{v.minor}.{v.micro}")
        error("Download from https://www.python.org/downloads/")
        sys.exit(1)
    log(f"Python {v.major}.{v.minor}.{v.micro} — OK")


def create_virtualenv():
    header("Step 2: Creating Virtual Environment")
    venv_dir = os.path.join(os.path.dirname(__file__), "venv")

    if os.path.exists(venv_dir):
        warn("Virtual environment already exists — skipping creation.")
        return venv_dir

    info("Creating venv/ ...")
    result = subprocess.run(
        [sys.executable, "-m", "venv", venv_dir],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        error(f"Failed to create venv: {result.stderr}")
        sys.exit(1)

    log(f"Virtual environment created at {venv_dir}")
    return venv_dir


def get_pip(venv_dir):
    """Return the pip path inside the venv."""
    if platform.system() == "Windows":
        return os.path.join(venv_dir, "Scripts", "pip.exe")
    return os.path.join(venv_dir, "bin", "pip")


def get_python(venv_dir):
    """Return the python path inside the venv."""
    if platform.system() == "Windows":
        return os.path.join(venv_dir, "Scripts", "python.exe")
    return os.path.join(venv_dir, "bin", "python")


def install_requirements(venv_dir):
    header("Step 3: Installing Requirements")
    pip = get_pip(venv_dir)
    req_file = os.path.join(os.path.dirname(__file__), "requirements.txt")

    if not os.path.exists(req_file):
        error("requirements.txt not found!")
        sys.exit(1)

    info("Upgrading pip first...")
    subprocess.run([pip, "install", "--upgrade", "pip"], check=True)

    info("Installing all packages (this may take 3-10 minutes)...")
    result = subprocess.run(
        [pip, "install", "-r", req_file],
        capture_output=False,   # Show live output
    )
    if result.returncode != 0:
        error("Some packages failed to install. Check errors above.")
        warn("Try running manually: pip install -r requirements.txt")
    else:
        log("All packages installed successfully")


def download_spacy_model(venv_dir):
    header("Step 4: Downloading spaCy Language Model")
    python = get_python(venv_dir)
    info("Downloading en_core_web_sm (small English model ~12MB)...")
    result = subprocess.run(
        [python, "-m", "spacy", "download", "en_core_web_sm"],
        capture_output=False
    )
    if result.returncode != 0:
        warn("spaCy model download failed. Run manually: python -m spacy download en_core_web_sm")
    else:
        log("spaCy model downloaded")


def create_directories():
    header("Step 5: Creating Project Directories")
    dirs = [
        "data",
        "data/audio",
        "data/audio/real",
        "data/audio/fake",
        "models",
        "logs",
        "static",
        "static/css",
    ]
    for d in dirs:
        full = os.path.join(os.path.dirname(__file__), d)
        os.makedirs(full, exist_ok=True)
        log(f"Created {d}/")


def create_env_file():
    header("Step 6: Creating .env File")
    env_path = os.path.join(os.path.dirname(__file__), ".env")
    if os.path.exists(env_path):
        warn(".env already exists — skipping.")
        return

    env_content = """# ============================================================
# .env — Environment Variables for Fraud Detection System
# ============================================================

# Flask
FLASK_ENV=development
FLASK_DEBUG=1
FLASK_SECRET=fraud-detection-barclays-2024

# Server
HOST=0.0.0.0
PORT=5000

# Logging
LOG_LEVEL=INFO
"""
    with open(env_path, "w") as f:
        f.write(env_content)
    log(".env file created")


def create_gitignore():
    gitignore_path = os.path.join(os.path.dirname(__file__), ".gitignore")
    if os.path.exists(gitignore_path):
        return
    content = """# Python
venv/
__pycache__/
*.pyc
*.pyo
*.pyd
.Python

# Logs & DB
logs/
*.log
feedback/feedback.db

# Models (large files)
models/

# Environment
.env

# Temp uploads
/tmp/

# VS Code
.vscode/settings.json

# OS
.DS_Store
Thumbs.db
"""
    with open(gitignore_path, "w") as f:
        f.write(content)
    log(".gitignore created")


def print_final_instructions(venv_dir):
    python = get_python(venv_dir)
    is_windows = platform.system() == "Windows"

    activate_cmd = (
        r"venv\Scripts\activate" if is_windows
        else "source venv/bin/activate"
    )

    header("Setup Complete!")
    print(f"{GREEN}{BOLD}Your project is ready to run!{RESET}\n")
    print(f"{BOLD}To start the server from VS Code Terminal:{RESET}")
    print()
    print(f"  {YELLOW}1. Activate the virtual environment:{RESET}")
    print(f"     {BLUE}{activate_cmd}{RESET}")
    print()
    print(f"  {YELLOW}2. Start the Flask server:{RESET}")
    print(f"     {BLUE}python app.py{RESET}")
    print()
    print(f"  {YELLOW}3. Open your browser at:{RESET}")
    print(f"     {BLUE}http://localhost:5000{RESET}")
    print()
    print(f"  {YELLOW}OR press F5 in VS Code (launch.json is pre-configured!){RESET}")
    print()
    print(f"{BOLD}API Endpoints available:{RESET}")
    endpoints = [
        "POST /api/scan/email       — Phishing email detection",
        "POST /api/scan/attachment  — File/attachment scanning",
        "POST /api/scan/website     — Website phishing check",
        "POST /api/scan/voice       — Deepfake voice detection",
        "POST /api/scan/prompt      — Prompt injection detection",
        "POST /api/scan/credentials — Credential exposure scan",
        "POST /api/scan/full        — Run all modules at once",
        "GET  /api/accuracy         — View accuracy benchmarks",
        "GET  /health               — Server health check",
    ]
    for ep in endpoints:
        print(f"  {BLUE}→{RESET} {ep}")
    print()
    print(f"{GREEN}{'='*60}{RESET}")


if __name__ == "__main__":
    check_python_version()
    venv_dir = create_virtualenv()
    install_requirements(venv_dir)
    download_spacy_model(venv_dir)
    create_directories()
    create_env_file()
    create_gitignore()
    print_final_instructions(venv_dir)
