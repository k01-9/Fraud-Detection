# ============================================================
# risk_engine/scorer.py
# Unified risk scoring engine — aggregates all module scores
# ============================================================

import os
import sys
import logging
from typing import Dict, Any, List, Optional

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from config import get_risk_tier

logger = logging.getLogger(__name__)


# ── Module Weight Configuration ───────────────────────────────
# How much each detection module contributes to the overall risk score
MODULE_WEIGHTS = {
    "phishing_email":    0.30,
    "credential_scan":   0.25,
    "attachment_scan":   0.20,
    "website_check":     0.15,
    "prompt_injection":  0.10,
}

MODULE_WEIGHTS_VOICE = {
    "voice_deepfake":    0.40,
    "phishing_email":    0.25,
    "credential_scan":   0.20,
    "prompt_injection":  0.15,
}


def compute_unified_score(module_results: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    """
    Compute a unified risk score from multiple module results.

    Args:
        module_results: Dict mapping module name to its result dict.
                       Each result must have a 'risk_score' key.

    Returns:
        {
            "unified_score": float (0–100),
            "risk_tier": dict,
            "module_scores": dict,
            "dominant_threat": str,
            "all_flags": list,
            "all_findings": list,
            "explanation": str,
            "recommendations": list,
        }
    """
    module_scores = {}
    all_flags = []
    all_findings = []
    all_recommendations = []

    # Extract scores and findings from each module
    for module_name, result in module_results.items():
        if result is None or "error" in result:
            continue

        score = result.get("risk_score", 0.0)
        module_scores[module_name] = score

        # Collect flags
        flags = result.get("flags", [])
        if isinstance(flags, list):
            all_flags.extend(flags)

        # Collect findings (from credential scanner, attachment scanner)
        findings = result.get("findings", [])
        if isinstance(findings, list):
            for f in findings:
                if isinstance(f, dict):
                    all_findings.append(f)
                elif isinstance(f, str):
                    all_flags.append(f)

        # Collect recommendations
        recs = result.get("recommendations", [])
        if isinstance(recs, list):
            all_recommendations.extend(recs)

    # ── Weighted Score Calculation ────────────────────────────
    # Use voice weights if voice module is present
    if "voice_deepfake" in module_scores:
        weights = MODULE_WEIGHTS_VOICE
    else:
        weights = MODULE_WEIGHTS

    weighted_sum = 0.0
    weight_used = 0.0

    for module_name, score in module_scores.items():
        weight = weights.get(module_name, 0.05)
        weighted_sum += score * weight
        weight_used += weight

    # Normalize by weights actually used
    if weight_used > 0:
        unified_score = weighted_sum / weight_used
    else:
        unified_score = 0.0

    # ── Boost for Critical Findings ───────────────────────────
    # If any single module hits critical threshold, boost overall score
    critical_modules = [name for name, score in module_scores.items() if score >= 80]
    if critical_modules:
        boost = min(len(critical_modules) * 5, 15)
        unified_score = min(unified_score + boost, 100)

    # ── Dominant Threat Identification ────────────────────────
    if module_scores:
        dominant_threat = max(module_scores, key=module_scores.get)
        dominant_score = module_scores[dominant_threat]
    else:
        dominant_threat = "none"
        dominant_score = 0.0

    # ── Risk Tier ─────────────────────────────────────────────
    risk_tier = get_risk_tier(unified_score)

    # ── Summary Explanation ───────────────────────────────────
    explanation = _build_explanation(
        unified_score, risk_tier, module_scores, dominant_threat, all_flags
    )

    # ── Remove duplicate recommendations ─────────────────────
    unique_recs = list(dict.fromkeys(all_recommendations))  # Preserve order, remove duplicates

    return {
        "unified_score": round(unified_score, 2),
        "risk_tier": risk_tier,
        "module_scores": module_scores,
        "dominant_threat": dominant_threat,
        "dominant_threat_score": round(dominant_score, 2),
        "all_flags": all_flags[:20],  # Cap at 20 flags for readability
        "all_findings": all_findings,
        "explanation": explanation,
        "recommendations": unique_recs[:10],  # Cap at 10 recommendations
        "critical_modules": critical_modules,
    }


def _build_explanation(
    score: float,
    tier: Dict,
    module_scores: Dict[str, float],
    dominant: str,
    flags: List[str],
) -> str:
    """Build a human-readable explanation of the risk assessment."""

    tier_name = tier["tier"]
    action = tier["action"]

    if score < 20:
        summary = "This content appears legitimate and safe."
    elif score < 40:
        summary = "Low risk detected. Minor concerns found but no strong indicators of fraud."
    elif score < 60:
        summary = "Moderate risk detected. Several suspicious patterns identified."
    elif score < 80:
        summary = "High risk detected. Multiple strong fraud indicators present."
    else:
        summary = "CRITICAL risk detected. This content shows strong indicators of AI-generated fraud."

    module_summary = ""
    if module_scores:
        high_modules = {k: v for k, v in module_scores.items() if v >= 50}
        if high_modules:
            module_names = {
                "phishing_email": "Phishing Email",
                "credential_scan": "Credential Exposure",
                "attachment_scan": "Attachment",
                "website_check": "Website",
                "voice_deepfake": "Voice Deepfake",
                "prompt_injection": "Prompt Injection",
            }
            flagged = [module_names.get(k, k) for k in high_modules.keys()]
            module_summary = f" Flagged modules: {', '.join(flagged)}."

    top_flag = f" Primary concern: {flags[0]}" if flags else ""

    return (
        f"[{tier_name}] Risk Score: {score:.0f}/100. "
        f"{summary}"
        f"{module_summary}"
        f"{top_flag} "
        f"Recommended action: {action}."
    )


def score_single_module(module_name: str, result: Dict[str, Any]) -> Dict[str, Any]:
    """
    Score a single module result with tier assignment.
    Used when only one module's result is available.
    """
    score = result.get("risk_score", 0.0)
    tier = get_risk_tier(score)

    return {
        "module": module_name,
        "risk_score": round(score, 2),
        "risk_tier": tier,
        "is_threat": score >= 50,
        "explanation": result.get("explanation", ""),
        "flags": result.get("flags", []),
        "recommendations": result.get("recommendations", []),
    }


def generate_audit_log(
    scan_id: str,
    module_results: Dict[str, Any],
    unified_result: Dict[str, Any],
    anonymized_source: str = "unknown"
) -> Dict[str, Any]:
    """
    Generate an anonymized audit log entry.
    NEVER stores raw content — only scores, flags, and metadata.
    """
    import time

    return {
        "scan_id": scan_id,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "source": anonymized_source,
        "unified_score": unified_result.get("unified_score", 0),
        "risk_tier": unified_result.get("risk_tier", {}).get("tier", "UNKNOWN"),
        "dominant_threat": unified_result.get("dominant_threat"),
        "modules_run": list(module_results.keys()),
        "module_scores": unified_result.get("module_scores", {}),
        "flags_count": len(unified_result.get("all_flags", [])),
        "action_taken": unified_result.get("risk_tier", {}).get("action", ""),
        # Explicitly NO raw content stored
    }
