# ============================================================
# feedback/feedback_db.py
# SQLite-based human feedback loop — stores anonymized corrections
# Enables continuous model improvement from false positive/negative reviews
# ============================================================

import os
import sys
import sqlite3
import logging
import uuid
import time
from typing import Dict, Any, List, Optional

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from config import FEEDBACK_DB

logger = logging.getLogger(__name__)


def _get_connection() -> sqlite3.Connection:
    """Get SQLite connection with row factory for dict-like access."""
    os.makedirs(os.path.dirname(FEEDBACK_DB), exist_ok=True)
    conn = sqlite3.connect(FEEDBACK_DB, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")  # Better concurrent access
    return conn


def initialize_db():
    """Create all required tables if they don't exist."""
    conn = _get_connection()
    try:
        conn.executescript("""
            -- Scan results (anonymized — no raw content stored)
            CREATE TABLE IF NOT EXISTS scan_results (
                scan_id         TEXT PRIMARY KEY,
                timestamp       TEXT NOT NULL,
                scan_type       TEXT NOT NULL,         -- email/attachment/url/voice/prompt
                risk_score      REAL NOT NULL,
                risk_tier       TEXT NOT NULL,
                module_scores   TEXT,                  -- JSON blob
                flags_count     INTEGER DEFAULT 0,
                source_hash     TEXT,                  -- SHA-256 of original content
                source_length   INTEGER DEFAULT 0,     -- Character count only
                reviewed        INTEGER DEFAULT 0,     -- 0=pending, 1=reviewed
                feedback_id     TEXT                   -- FK to feedback table
            );

            -- Human reviewer feedback
            CREATE TABLE IF NOT EXISTS feedback (
                feedback_id     TEXT PRIMARY KEY,
                scan_id         TEXT NOT NULL,
                timestamp       TEXT NOT NULL,
                original_score  REAL NOT NULL,
                original_tier   TEXT NOT NULL,
                reviewer_label  INTEGER NOT NULL,      -- 0=legitimate, 1=fraud
                was_correct     INTEGER NOT NULL,      -- 1=model was right, 0=false positive/negative
                error_type      TEXT,                  -- "false_positive", "false_negative", or NULL
                reviewer_notes  TEXT,                  -- Optional human notes (anonymized)
                module          TEXT,                  -- Which module made the error
                FOREIGN KEY (scan_id) REFERENCES scan_results (scan_id)
            );

            -- Model performance tracking
            CREATE TABLE IF NOT EXISTS model_metrics (
                metric_id       TEXT PRIMARY KEY,
                timestamp       TEXT NOT NULL,
                module          TEXT NOT NULL,
                true_positives  INTEGER DEFAULT 0,
                true_negatives  INTEGER DEFAULT 0,
                false_positives INTEGER DEFAULT 0,
                false_negatives INTEGER DEFAULT 0,
                accuracy        REAL,
                precision_val   REAL,
                recall          REAL,
                f1_score        REAL
            );

            -- Fraud pattern registry (emerging patterns from feedback)
            CREATE TABLE IF NOT EXISTS fraud_patterns (
                pattern_id      TEXT PRIMARY KEY,
                timestamp       TEXT NOT NULL,
                pattern_type    TEXT NOT NULL,         -- email/url/voice/prompt
                pattern_hash    TEXT NOT NULL,         -- Hash of pattern (not raw content)
                frequency       INTEGER DEFAULT 1,
                first_seen      TEXT NOT NULL,
                last_seen       TEXT NOT NULL,
                confirmed       INTEGER DEFAULT 0      -- 1=confirmed by reviewer
            );

            -- Indices for performance
            CREATE INDEX IF NOT EXISTS idx_scan_type ON scan_results(scan_type);
            CREATE INDEX IF NOT EXISTS idx_scan_timestamp ON scan_results(timestamp);
            CREATE INDEX IF NOT EXISTS idx_feedback_scan ON feedback(scan_id);
            CREATE INDEX IF NOT EXISTS idx_feedback_module ON feedback(module);
        """)
        conn.commit()
        logger.info(f"Feedback database initialized at {FEEDBACK_DB}")
    except Exception as e:
        logger.error(f"DB initialization failed: {e}")
    finally:
        conn.close()


def log_scan_result(
    scan_type: str,
    risk_score: float,
    risk_tier: str,
    module_scores: Dict[str, float],
    source_hash: str,
    source_length: int = 0,
) -> str:
    """
    Log an anonymized scan result. Returns scan_id for reference.
    NEVER stores raw content — only metadata and scores.
    """
    import json

    scan_id = str(uuid.uuid4())
    timestamp = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

    conn = _get_connection()
    try:
        conn.execute("""
            INSERT INTO scan_results
            (scan_id, timestamp, scan_type, risk_score, risk_tier, module_scores,
             source_hash, source_length)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            scan_id, timestamp, scan_type, risk_score, risk_tier,
            json.dumps(module_scores), source_hash, source_length
        ))
        conn.commit()
        logger.debug(f"Logged scan: {scan_id[:8]}... | {scan_type} | score={risk_score:.1f}")
    except Exception as e:
        logger.error(f"Failed to log scan result: {e}")
    finally:
        conn.close()

    return scan_id


def submit_feedback(
    scan_id: str,
    reviewer_label: int,
    module: str,
    reviewer_notes: str = "",
) -> Dict[str, Any]:
    """
    Submit human reviewer feedback for a scan result.

    Args:
        scan_id: The scan to provide feedback on
        reviewer_label: 0=legitimate (false positive), 1=fraud (true positive)
        module: Which module's result is being corrected
        reviewer_notes: Optional anonymized notes (max 500 chars)

    Returns:
        Success status and feedback summary
    """
    conn = _get_connection()
    try:
        # Get original scan
        row = conn.execute(
            "SELECT * FROM scan_results WHERE scan_id = ?", (scan_id,)
        ).fetchone()

        if not row:
            return {"success": False, "error": "Scan ID not found"}

        original_score = row["risk_score"]
        original_tier = row["risk_tier"]

        # Determine if model was correct
        model_said_fraud = original_score >= 50
        reviewer_says_fraud = reviewer_label == 1
        was_correct = int(model_said_fraud == reviewer_says_fraud)

        error_type = None
        if not was_correct:
            error_type = "false_positive" if model_said_fraud else "false_negative"

        feedback_id = str(uuid.uuid4())
        timestamp = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

        # Anonymize notes — strip any potential PII
        safe_notes = reviewer_notes[:500].encode("ascii", "ignore").decode("ascii") if reviewer_notes else ""

        conn.execute("""
            INSERT INTO feedback
            (feedback_id, scan_id, timestamp, original_score, original_tier,
             reviewer_label, was_correct, error_type, reviewer_notes, module)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            feedback_id, scan_id, timestamp, original_score, original_tier,
            reviewer_label, was_correct, error_type, safe_notes, module
        ))

        # Mark scan as reviewed
        conn.execute(
            "UPDATE scan_results SET reviewed=1, feedback_id=? WHERE scan_id=?",
            (feedback_id, scan_id)
        )
        conn.commit()

        # Update metrics
        _update_metrics(conn, module, was_correct, reviewer_label, model_said_fraud)

        logger.info(
            f"Feedback received: scan={scan_id[:8]}... | "
            f"correct={was_correct} | error_type={error_type}"
        )

        return {
            "success": True,
            "feedback_id": feedback_id,
            "was_correct": bool(was_correct),
            "error_type": error_type,
            "message": (
                "Thank you! Model was correct." if was_correct
                else f"Recorded {error_type}. This will help improve the model."
            ),
        }

    except Exception as e:
        logger.error(f"Feedback submission failed: {e}")
        return {"success": False, "error": str(e)}
    finally:
        conn.close()


def _update_metrics(conn, module: str, was_correct: int, reviewer_label: int, model_predicted_positive: bool):
    """Update running model performance metrics."""
    import json

    metric_id = str(uuid.uuid4())
    timestamp = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

    tp = int(was_correct and reviewer_label == 1)
    tn = int(was_correct and reviewer_label == 0)
    fp = int(not was_correct and model_predicted_positive)
    fn = int(not was_correct and not model_predicted_positive)

    conn.execute("""
        INSERT INTO model_metrics
        (metric_id, timestamp, module, true_positives, true_negatives, false_positives, false_negatives)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (metric_id, timestamp, module, tp, tn, fp, fn))


def get_performance_summary(module: Optional[str] = None) -> Dict[str, Any]:
    """Get aggregated model performance stats."""
    conn = _get_connection()
    try:
        query = """
            SELECT
                module,
                SUM(true_positives) as tp,
                SUM(true_negatives) as tn,
                SUM(false_positives) as fp,
                SUM(false_negatives) as fn
            FROM model_metrics
        """
        params = []
        if module:
            query += " WHERE module = ?"
            params.append(module)
        query += " GROUP BY module"

        rows = conn.execute(query, params).fetchall()
        results = {}

        for row in rows:
            tp, tn, fp, fn = row["tp"], row["tn"], row["fp"], row["fn"]
            total = tp + tn + fp + fn

            if total == 0:
                continue

            accuracy = (tp + tn) / total if total > 0 else 0
            precision = tp / (tp + fp) if (tp + fp) > 0 else 0
            recall = tp / (tp + fn) if (tp + fn) > 0 else 0
            f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0

            results[row["module"]] = {
                "total_reviewed": total,
                "true_positives": tp,
                "true_negatives": tn,
                "false_positives": fp,
                "false_negatives": fn,
                "accuracy": round(accuracy, 4),
                "precision": round(precision, 4),
                "recall": round(recall, 4),
                "f1_score": round(f1, 4),
                "false_positive_rate": round(fp / (fp + tn) if (fp + tn) > 0 else 0, 4),
            }

        return results

    except Exception as e:
        logger.error(f"Performance summary failed: {e}")
        return {}
    finally:
        conn.close()


def get_recent_scans(limit: int = 50, scan_type: Optional[str] = None) -> List[Dict]:
    """Get recent scan results for dashboard display."""
    conn = _get_connection()
    try:
        query = "SELECT * FROM scan_results"
        params = []
        if scan_type:
            query += " WHERE scan_type = ?"
            params.append(scan_type)
        query += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)

        rows = conn.execute(query, params).fetchall()
        return [dict(row) for row in rows]

    except Exception as e:
        logger.error(f"Failed to fetch recent scans: {e}")
        return []
    finally:
        conn.close()


# Initialize DB on import
initialize_db()
