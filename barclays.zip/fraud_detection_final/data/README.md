# data/ — Training Datasets Directory

Place your downloaded datasets here. The system works without any datasets
(using rule-based detection + built-in synthetic data), but adding real
datasets improves ML model accuracy significantly.

## Phishing Email Model Files

Place these CSV files here for training the phishing email classifier:

### data/enron_emails.csv
- Download: https://www.kaggle.com/datasets/wcukierski/enron-email-dataset
- Expected columns: any column named "body", "message", "text", or "email"
- Label: All Enron emails are LEGITIMATE (label=0, auto-assigned)
- Size: ~500,000 rows

### data/phishing_emails.csv
- Download: https://www.kaggle.com/datasets/naserabdullahalam/phishing-email-dataset
- OR: https://www.kaggle.com/datasets/subhajournal/phishingemails
- Expected columns: "text" (or similar) + "label" (1=phishing, 0=legitimate)
- Size: varies by source, typically 10,000–50,000 rows

### data/combined_emails.csv (optional)
- Any CSV with both phishing and legitimate emails
- Must have a "label" column (1=phishing, 0=legitimate)

## Website Phishing Checker Files

### data/phishtank.csv (optional)
- Download: curl -o data/phishtank.csv "http://data.phishtank.com/data/online-valid.csv"
- Contains verified phishing URLs for testing the website checker module

## Voice Deepfake Model Files

### data/audio/real/
- Place genuine (human) voice recordings here
- Supported formats: .wav, .flac, .mp3
- Recommended: ASVspoof 2019 LA bonafide samples
- Download: https://www.asvspoof.org/index2019.html

### data/audio/fake/
- Place AI-generated/deepfake voice recordings here
- Supported formats: .wav, .flac, .mp3
- Recommended: ASVspoof 2019 LA spoof samples

## Training Commands

Once datasets are in place:

```bash
# Train phishing email model
python modules/phishing_email/trainer.py

# Train voice deepfake model
python modules/voice_deepfake/trainer.py --data_dir data/audio
```

Models are saved to the models/ directory and loaded automatically
by the detectors when the Flask app runs.
