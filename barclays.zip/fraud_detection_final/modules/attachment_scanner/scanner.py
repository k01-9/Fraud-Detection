# ============================================================
# modules/attachment_scanner/scanner.py  (ENHANCED v2.0)
# Enhanced static analysis: PDF/Office/ZIP + entropy check
# + polyglot detection + DDE attack detection
# ============================================================

import os
import sys
import logging
import hashlib
import math
import zipfile
from typing import Dict, Any, List

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from config import ATTACHMENT

logger = logging.getLogger(__name__)


def _calculate_entropy(data: bytes) -> float:
    """
    Calculate Shannon entropy of bytes.
    High entropy (>7.2) may indicate encrypted/packed/compressed malicious payload.
    This is a key heuristic for detecting novel malware that bypasses signature checks.
    """
    if not data:
        return 0.0
    freq = {}
    for byte in data:
        freq[byte] = freq.get(byte, 0) + 1
    entropy = -sum(
        (count / len(data)) * math.log2(count / len(data))
        for count in freq.values()
    )
    return round(entropy, 4)


def _sha256_hash(file_path: str) -> str:
    """Compute SHA-256 hash for file identification (no raw content stored)."""
    try:
        h = hashlib.sha256()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()
    except Exception:
        return "hash_unavailable"


def scan_pdf(file_path: str) -> Dict[str, Any]:
    """
    Enhanced PDF scanning:
    - v1: basic keyword scan
    - v2: + JavaScript parsing, URI extraction, embedded file detection,
           entropy analysis of streams, annotation action checks
    """
    findings = []
    risk_score = 0

    try:
        import fitz  # PyMuPDF

        doc = fitz.open(file_path)
        full_text = ""

        for page_num in range(len(doc)):
            page = doc.load_page(page_num)
            full_text += page.get_text()

            # Check annotations for suspicious actions
            for annot in page.annots():
                if annot.type[1] in ["Link", "Widget"]:
                    if hasattr(annot, "uri") and annot.uri:
                        if any(kw in annot.uri.lower() for kw in ["javascript:", "data:", "file:"]):
                            findings.append(f"Suspicious annotation URI on page {page_num+1}: {annot.uri[:60]}")
                            risk_score += 35

        # Check raw PDF source for risk keywords
        doc_bytes = open(file_path, "rb").read()
        raw_text  = doc_bytes.decode("latin-1", errors="ignore")

        for keyword in ATTACHMENT["pdf_risk_keywords"]:
            count = raw_text.count(keyword)
            if count > 0:
                findings.append(f"PDF contains '{keyword}' ({count}x) — often used in exploit PDFs")
                risk_score += 25 if keyword in ["/JavaScript", "/JS", "/Launch", "/OpenAction"] else 15

        # Check metadata for anomalies
        metadata = doc.metadata
        if metadata:
            producer = metadata.get("producer", "")
            if any(sus in producer.lower() for sus in ["malicious", "exploit", "unknown"]):
                findings.append(f"Suspicious PDF producer: '{producer}'")
                risk_score += 20

        # Entropy check on raw file
        entropy = _calculate_entropy(doc_bytes[:50000])
        if entropy > ATTACHMENT["entropy_threshold"]:
            findings.append(f"High entropy ({entropy:.2f}) — may contain encrypted/packed payload")
            risk_score += 20

        # Page count anomaly (single-page with heavy JS = suspicious)
        if len(doc) == 1 and "/JavaScript" in raw_text:
            findings.append("Single-page PDF with JavaScript — typical of exploit PDFs")
            risk_score += 25

        # Embedded files
        if "/EmbeddedFile" in raw_text:
            findings.append("PDF contains embedded files — potential container for malware")
            risk_score += 30

        # DDE-like attack patterns in text
        if "=cmd" in full_text.lower() or "=powershell" in full_text.lower():
            findings.append("DDE-like formula injection detected in PDF text")
            risk_score += 40

        doc.close()

    except ImportError:
        findings.append("PyMuPDF (fitz) not installed — PDF analysis limited. Run: pip install pymupdf")
        risk_score += 5
    except Exception as e:
        findings.append(f"PDF analysis error: {str(e)[:80]}")
        risk_score += 10

    return {"findings": findings, "risk_score": min(risk_score, 100), "type": "pdf"}


def scan_office(file_path: str) -> Dict[str, Any]:
    """
    Enhanced Office document scanning:
    - VBA macro analysis with oletools
    - DDE injection detection
    - Suspicious relationship (external OLE links)
    - Entropy analysis of binary content
    """
    findings = []
    risk_score = 0
    ext = os.path.splitext(file_path)[1].lower()

    # ── Macro analysis with oletools ──────────────────────────
    try:
        from oletools.olevba import VBA_Parser, TYPE_OLE, TYPE_OpenXML

        parser = VBA_Parser(file_path)
        if parser.detect_vba_macros():
            findings.append("VBA macros detected in document")
            risk_score += 40

            for (filename, stream_path, vba_filename, vba_code) in parser.extract_macros():
                vba_lower = vba_code.lower()
                for keyword in ATTACHMENT["macro_risk_keywords"]:
                    if keyword.lower() in vba_lower:
                        findings.append(f"High-risk macro keyword: '{keyword}' in {vba_filename}")
                        risk_score += 20

                # Check for obfuscation (Base64 in macros)
                if "base64" in vba_lower or "chr(" in vba_lower:
                    findings.append("Obfuscated macro code detected (Base64/Chr encoding)")
                    risk_score += 30

                # Network activity
                if any(kw in vba_lower for kw in ["http", "https", "ftp", "url", "wget", "curl"]):
                    findings.append("Macro contains network activity — may download malware")
                    risk_score += 35

            # Auto-execution macros (highest risk)
            for keyword in ["AutoOpen", "Document_Open", "Workbook_Open", "Auto_Open"]:
                for (fn, sp, vba_fn, vba_code) in parser.extract_macros():
                    if keyword in vba_code:
                        findings.append(f"Auto-execution macro '{keyword}' — runs without user interaction")
                        risk_score += 40
                        break

        parser.close()

    except ImportError:
        findings.append("oletools not installed — macro analysis skipped. Run: pip install oletools")
    except Exception as e:
        findings.append(f"Macro analysis error: {str(e)[:80]}")

    # ── DDE Injection (xlsx/docx) ─────────────────────────────
    if ext in [".docx", ".xlsx", ".pptx"]:
        try:
            with zipfile.ZipFile(file_path, "r") as z:
                for name in z.namelist():
                    if name.endswith(".xml"):
                        with z.open(name) as f:
                            content = f.read().decode("utf-8", errors="ignore").lower()
                            if "=cmd" in content or "=powershell" in content or "dde(" in content:
                                findings.append(f"DDE formula injection detected in {name}")
                                risk_score += 45
                            if "externalreference" in content and "http" in content:
                                findings.append(f"External link in {name} — may phone home")
                                risk_score += 25
        except Exception:
            pass

    # ── File entropy check ────────────────────────────────────
    try:
        with open(file_path, "rb") as f:
            raw = f.read(50000)
        entropy = _calculate_entropy(raw)
        if entropy > ATTACHMENT["entropy_threshold"]:
            findings.append(f"High entropy ({entropy:.2f}) — possibly encrypted/packed payload")
            risk_score += 20
    except Exception:
        pass

    if not findings:
        findings.append("No macro or DDE threats detected. Document appears clean.")

    return {"findings": findings, "risk_score": min(risk_score, 100), "type": "office"}


def scan_zip(file_path: str) -> Dict[str, Any]:
    """
    Enhanced ZIP scanning:
    - Nested ZIP detection (Zip bomb)
    - Suspicious filenames inside
    - Extension mismatch detection (polyglot files)
    - Compressed executable detection
    """
    findings = []
    risk_score = 0

    try:
        with zipfile.ZipFile(file_path, "r") as z:
            file_list = z.namelist()
            total_compressed = sum(info.compress_size for info in z.infolist())
            total_uncompressed = sum(info.file_size for info in z.infolist())

            # ZIP bomb detection (compression ratio > 100:1)
            if total_compressed > 0:
                compression_ratio = total_uncompressed / total_compressed
                if compression_ratio > 100:
                    findings.append(
                        f"Potential ZIP bomb: {compression_ratio:.0f}:1 compression ratio"
                    )
                    risk_score += 70

            # Scan filenames for suspicious extensions
            for filename in file_list:
                lower = filename.lower()
                # Nested ZIPs
                if lower.endswith(".zip") or lower.endswith(".7z") or lower.endswith(".rar"):
                    findings.append(f"Nested archive detected: {filename}")
                    risk_score += 20

                # Executable files inside ZIP
                for sus_ext in ATTACHMENT["suspicious_extensions"]:
                    if lower.endswith(sus_ext):
                        findings.append(f"Suspicious executable in archive: {filename}")
                        risk_score += 50
                        break

                # Extension mismatch (polyglot files)
                if "." in filename:
                    ext = "." + filename.rsplit(".", 1)[-1].lower()
                    apparent_ext = "." + filename.split(".")[0].rsplit(".", 1)[-1].lower() if "." in filename.split(".")[0] else ""
                    if apparent_ext in [".pdf", ".doc", ".jpg"] and ext in ATTACHMENT["suspicious_extensions"]:
                        findings.append(f"Extension mismatch (polyglot file): {filename}")
                        risk_score += 40

            # Entropy of first suspicious file
            for filename in file_list[:5]:
                try:
                    with z.open(filename) as f:
                        data = f.read(10000)
                        entropy = _calculate_entropy(data)
                        if entropy > ATTACHMENT["entropy_threshold"]:
                            findings.append(
                                f"High entropy in '{filename}' ({entropy:.2f}) — possible packed payload"
                            )
                            risk_score += 25
                            break
                except Exception:
                    pass

    except zipfile.BadZipFile:
        findings.append("File is not a valid ZIP archive — may be a disguised executable")
        risk_score += 30
    except Exception as e:
        findings.append(f"ZIP analysis error: {str(e)[:80]}")

    if not findings:
        findings.append("ZIP archive appears clean. No malicious content detected.")

    return {"findings": findings, "risk_score": min(risk_score, 100), "type": "zip"}


def scan_attachment(file_path: str) -> Dict[str, Any]:
    """
    Master attachment scanner. Routes to appropriate scanner by extension.
    Returns unified risk score and findings.
    """
    if not os.path.exists(file_path):
        return {"error": "File not found", "risk_score": 0, "is_malicious": False}

    filename = os.path.basename(file_path)
    ext = os.path.splitext(filename)[1].lower()
    file_size_mb = os.path.getsize(file_path) / (1024 * 1024)
    file_hash = _sha256_hash(file_path)

    logger.info(f"Scanning attachment: {filename} ({file_size_mb:.2f}MB)")

    # ── Size check ────────────────────────────────────────────
    if file_size_mb > ATTACHMENT["max_file_size_mb"]:
        return {
            "error": f"File too large ({file_size_mb:.1f}MB > {ATTACHMENT['max_file_size_mb']}MB limit)",
            "risk_score": 0, "is_malicious": False,
        }

    all_findings = []
    risk_score = 0

    # ── Immediate flag: known malicious extension ─────────────
    if ext in ATTACHMENT["suspicious_extensions"]:
        all_findings.append(
            f"File extension '{ext}' is inherently dangerous — executable/script type"
        )
        risk_score = max(risk_score, 85)

    # ── Route to specific scanner ─────────────────────────────
    scan_result = {}

    if ext == ".pdf":
        scan_result = scan_pdf(file_path)
    elif ext in [".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx"]:
        scan_result = scan_office(file_path)
    elif ext == ".zip":
        scan_result = scan_zip(file_path)
    elif ext in [".txt", ".csv"]:
        # Scan text files for embedded credentials
        try:
            from modules.credential_scanner.scanner import scan_file_for_credentials
            cred_result = scan_file_for_credentials(file_path)
            if cred_result.get("total_found", 0) > 0:
                all_findings.append(
                    f"Text file contains {cred_result['total_found']} credential(s) — "
                    f"possible data exfiltration: {cred_result.get('explanation', '')}"
                )
                risk_score = max(risk_score, cred_result["risk_score"])
        except Exception:
            pass
        scan_result = {"findings": all_findings, "risk_score": risk_score, "type": "text"}
    elif ext in [".png", ".jpg", ".jpeg"]:
        # Steganography hint via entropy
        try:
            with open(file_path, "rb") as f:
                data = f.read()
            entropy = _calculate_entropy(data)
            if entropy > 7.8:
                all_findings.append(
                    f"Unusually high image entropy ({entropy:.2f}) — possible steganographic payload"
                )
                risk_score = max(risk_score, 30)
        except Exception:
            pass
        scan_result = {"findings": all_findings, "risk_score": risk_score, "type": "image"}
    else:
        # Generic entropy check for unknown types
        try:
            with open(file_path, "rb") as f:
                data = f.read(50000)
            entropy = _calculate_entropy(data)
            if entropy > ATTACHMENT["entropy_threshold"]:
                all_findings.append(
                    f"Unknown file type with high entropy ({entropy:.2f}) — possible malware"
                )
                risk_score = max(risk_score, 40)
        except Exception:
            pass
        scan_result = {"findings": all_findings, "risk_score": risk_score, "type": "unknown"}

    # Merge findings
    all_findings.extend(scan_result.get("findings", []))
    final_score = max(risk_score, scan_result.get("risk_score", 0))

    if not all_findings:
        all_findings.append("Attachment appears clean. No threats detected.")

    return {
        "filename":     filename,
        "file_hash":    file_hash,
        "file_size_mb": round(file_size_mb, 3),
        "extension":    ext,
        "file_type":    scan_result.get("type", "unknown"),
        "findings":     all_findings,
        "risk_score":   round(min(final_score, 100), 2),
        "is_malicious": final_score >= 50,
        "explanation": (
            f"File shows {len(all_findings)} threat indicator(s). "
            f"Risk: {round(final_score)}. Primary: {all_findings[0]}"
            if all_findings and final_score > 10 else
            "Attachment appears safe. No malicious content detected."
        ),
        "recommendation": (
            "Quarantine immediately — do not open" if final_score >= 80 else
            "Treat with caution — scan with additional tools" if final_score >= 50 else
            "Appears safe for normal use"
        ),
    }
