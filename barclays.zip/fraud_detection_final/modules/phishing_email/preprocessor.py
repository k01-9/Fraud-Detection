# ============================================================
# modules/phishing_email/preprocessor.py
# PII removal + email cleaning pipeline
# ============================================================

import re
import logging
from typing import Dict, Any

logger = logging.getLogger(__name__)


# ── PII Removal Patterns ──────────────────────────────────────
PII_PATTERNS = {
    "email":       (r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+",    "[EMAIL_REDACTED]"),
    "phone":       (r"(\+?\d{1,3}[\s\-]?)?\(?\d{3}\)?[\s\-]?\d{3}[\s\-]?\d{4}", "[PHONE_REDACTED]"),
    "credit_card": (r"\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13})\b", "[CC_REDACTED]"),
    "ssn":         (r"\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b",                    "[SSN_REDACTED]"),
    "ip_address":  (r"\b(?:\d{1,3}\.){3}\d{1,3}\b",                        "[IP_REDACTED]"),
    "url":         (r"https?://[^\s<>\"]+",                                  "[URL_REDACTED]"),
    "name_pattern":(r"\b([A-Z][a-z]+\s[A-Z][a-z]+)\b",                     "[NAME_REDACTED]"),
}


def remove_pii(text: str) -> str:
    """Strip all PII from text, replacing with safe placeholders."""
    for label, (pattern, replacement) in PII_PATTERNS.items():
        text = re.sub(pattern, replacement, text)
    return text


def clean_email_text(raw: str) -> str:
    """
    Clean raw email text:
    1. Remove HTML tags
    2. Collapse whitespace
    3. Remove non-ASCII junk
    4. Normalize case
    """
    # Strip HTML
    text = re.sub(r"<[^>]+>", " ", raw)
    # Remove base64 blobs (common in email headers)
    text = re.sub(r"[A-Za-z0-9+/=]{60,}", "[BASE64_BLOB]", text)
    # Remove excessive whitespace/newlines
    text = re.sub(r"\s+", " ", text).strip()
    # Remove non-printable characters
    text = re.sub(r"[^\x20-\x7E]", "", text)
    return text


def extract_email_features(raw_email: str) -> Dict[str, Any]:
    """
    Extract structural features from an email for ML + rule-based scoring.
    Returns a dict of features (all anonymized).
    """
    features = {}

    # Urgency keywords
    urgency_words = [
        "urgent", "immediately", "action required", "verify now",
        "account suspended", "limited time", "expires", "click here",
        "confirm your", "update your", "unusual activity", "suspicious login",
        "security alert", "final notice", "last chance", "your account",
        "winner", "prize", "congratulations", "free", "guaranteed",
    ]
    lower = raw_email.lower()
    features["urgency_count"] = sum(1 for w in urgency_words if w in lower)

    # Exclamation marks (spam indicator)
    features["exclamation_count"] = raw_email.count("!")

    # URL count
    features["url_count"] = len(re.findall(r"https?://", raw_email))

    # Mismatch: display text vs actual link (basic heuristic)
    features["link_text_mismatch"] = bool(
        re.search(r">(www\.[^<]+|https?://[^<]+)<", raw_email)
    )

    # Has HTML (phishing often uses HTML formatting)
    features["has_html"] = bool(re.search(r"<html|<body|<a href", raw_email, re.IGNORECASE))

    # Generic greeting (phishing rarely knows your name)
    features["generic_greeting"] = bool(
        re.search(r"dear (customer|user|account holder|valued|sir|madam)", lower)
    )

    # Misspellings of common brands (simple heuristic)
    brand_typos = [
        r"paypa[l1]", r"amaz0n", r"g00gle", r"micros0ft",
        r"barc1ays", r"app1e", r"netf1ix",
    ]
    features["brand_typo"] = any(re.search(p, lower) for p in brand_typos)

    # Request for credentials
    features["credential_request"] = bool(
        re.search(r"(enter|provide|confirm|update|verify).{0,30}(password|pin|cvv|ssn|account)", lower)
    )

    # Suspicious sender domain mismatch hint
    features["suspicious_reply_to"] = bool(
        re.search(r"reply-to:.+@(?!barclays|hsbc|paypal|amazon|google|microsoft)", raw_email, re.IGNORECASE)
    )

    # Text length
    features["text_length"] = len(raw_email)

    return features


def preprocess_email(raw_email: str) -> Dict[str, Any]:
    """
    Full preprocessing pipeline for one email.
    Returns:
        - cleaned_text: sanitized, PII-stripped text for the model
        - features: extracted heuristic features
        - original_length: for logging
    """
    original_length = len(raw_email)

    # Step 1: Extract features BEFORE PII removal (URLs, etc. still intact)
    features = extract_email_features(raw_email)

    # Step 2: Clean HTML and noise
    cleaned = clean_email_text(raw_email)

    # Step 3: Remove PII — NEVER store raw personal data
    cleaned = remove_pii(cleaned)

    logger.debug(f"Preprocessed email: {original_length} → {len(cleaned)} chars")

    return {
        "cleaned_text": cleaned,
        "features": features,
        "original_length": original_length,
    }
