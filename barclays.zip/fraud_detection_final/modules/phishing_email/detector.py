# ============================================================
# modules/phishing_email/detector.py
# DistilBERT-based phishing email classifier
# ============================================================

import os
import logging
import numpy as np
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

# Lazy imports to avoid crash if transformers not installed yet
_tokenizer = None
_model = None
_pipeline = None


def _load_model(model_path: Optional[str] = None):
    """Lazy-load the model. Uses fine-tuned if available, else base DistilBERT."""
    global _tokenizer, _model, _pipeline

    if _pipeline is not None:
        return _pipeline

    try:
        from transformers import pipeline, AutoTokenizer, AutoModelForSequenceClassification
        from config import PHISHING_EMAIL

        # Use fine-tuned model if it exists, otherwise fall back to base
        load_path = model_path or PHISHING_EMAIL["fine_tuned_path"]

        if os.path.exists(load_path):
            logger.info(f"Loading fine-tuned phishing model from {load_path}")
            _pipeline = pipeline(
                "text-classification",
                model=load_path,
                tokenizer=load_path,
                device=-1,  # CPU only — no external calls
            )
        else:
            logger.warning("Fine-tuned model not found. Using base DistilBERT (lower accuracy).")
            logger.warning("Run modules/phishing_email/trainer.py to fine-tune first.")
            # Use a publicly available phishing detection model from HuggingFace
            _pipeline = pipeline(
                "text-classification",
                model="distilbert-base-uncased",
                device=-1,
            )

        return _pipeline

    except Exception as e:
        logger.error(f"Failed to load phishing model: {e}")
        return None


def _rule_based_score(features: Dict[str, Any]) -> float:
    """
    Rule-based scoring from extracted features.
    Returns a score 0–100 (higher = more suspicious).
    This acts as a safety net even if the ML model is unavailable.
    """
    score = 0.0

    # Urgency language
    urgency = features.get("urgency_count", 0)
    score += min(urgency * 8, 40)           # Up to 40 points

    # Credential harvesting request
    if features.get("credential_request"):
        score += 25

    # Brand typosquatting
    if features.get("brand_typo"):
        score += 20

    # Generic greeting (dear customer)
    if features.get("generic_greeting"):
        score += 10

    # Suspicious reply-to domain
    if features.get("suspicious_reply_to"):
        score += 15

    # Many exclamation marks
    excl = features.get("exclamation_count", 0)
    score += min(excl * 2, 10)

    # Many URLs
    urls = features.get("url_count", 0)
    score += min(urls * 3, 15)

    # Link text mismatch
    if features.get("link_text_mismatch"):
        score += 10

    return min(score, 100)


def detect_phishing_email(preprocessed: Dict[str, Any]) -> Dict[str, Any]:
    """
    Main detection function.

    Args:
        preprocessed: Output from preprocessor.preprocess_email()

    Returns:
        {
            "is_phishing": bool,
            "confidence": float (0–1),
            "risk_score": float (0–100),
            "ml_score": float,
            "rule_score": float,
            "explanation": str,
            "flags": list[str]
        }
    """
    text = preprocessed["cleaned_text"]
    features = preprocessed["features"]

    # ── Rule-based score ──────────────────────────────────────
    rule_score = _rule_based_score(features)

    # ── ML score ─────────────────────────────────────────────
    ml_score = 50.0  # Default neutral if model unavailable
    ml_confidence = 0.5
    model_used = "rule_based_only"

    pipe = _load_model()
    if pipe is not None:
        try:
            from config import PHISHING_EMAIL
            max_len = PHISHING_EMAIL["max_length"]

            # Truncate text to model's max token limit
            truncated = text[:max_len * 4]  # rough char estimate
            result = pipe(truncated, truncation=True, max_length=max_len)[0]

            label = result["label"].upper()
            score_val = result["score"]

            # Normalize: some models output LABEL_0/LABEL_1
            if label in ["LABEL_1", "PHISHING", "SPAM", "MALICIOUS"]:
                ml_confidence = score_val
                ml_score = score_val * 100
            elif label in ["LABEL_0", "SAFE", "HAM", "LEGITIMATE"]:
                ml_confidence = 1 - score_val
                ml_score = (1 - score_val) * 100
            else:
                ml_score = score_val * 100
                ml_confidence = score_val

            model_used = "distilbert_classifier"

        except Exception as e:
            logger.warning(f"ML model inference failed: {e}. Using rule-based only.")

    # ── Combined Score (weighted ensemble) ───────────────────
    # Rule-based: 40% weight | ML: 60% weight
    if model_used == "rule_based_only":
        final_score = rule_score
    else:
        final_score = (0.4 * rule_score) + (0.6 * ml_score)

    is_phishing = final_score >= 50

    # ── Build explanation ─────────────────────────────────────
    flags = []
    explanations = []

    if features.get("urgency_count", 0) >= 2:
        flags.append("urgency_language")
        explanations.append(f"Contains {features['urgency_count']} urgency phrases (e.g. 'act now', 'account suspended')")

    if features.get("credential_request"):
        flags.append("credential_harvesting")
        explanations.append("Requests sensitive credentials (password, PIN, CVV)")

    if features.get("brand_typo"):
        flags.append("brand_spoofing")
        explanations.append("Contains typosquatted brand name (e.g. 'paypa1' instead of 'paypal')")

    if features.get("generic_greeting"):
        flags.append("generic_greeting")
        explanations.append("Uses generic greeting ('Dear Customer') instead of recipient's name")

    if features.get("suspicious_reply_to"):
        flags.append("suspicious_reply_to")
        explanations.append("Reply-To address points to unrelated/suspicious domain")

    if features.get("link_text_mismatch"):
        flags.append("link_mismatch")
        explanations.append("Hyperlink display text doesn't match actual URL destination")

    if ml_score > 70 and model_used != "rule_based_only":
        explanations.append(f"AI language model flagged content as phishing (confidence: {ml_confidence:.1%})")

    if not explanations:
        explanations.append("Email appears legitimate. No suspicious patterns detected.")

    return {
        "is_phishing": is_phishing,
        "confidence": round(ml_confidence, 4),
        "risk_score": round(final_score, 2),
        "ml_score": round(ml_score, 2),
        "rule_score": round(rule_score, 2),
        "model_used": model_used,
        "flags": flags,
        "explanation": " | ".join(explanations),
        "recommendation": "Block and report" if is_phishing else "Appears safe",
    }
