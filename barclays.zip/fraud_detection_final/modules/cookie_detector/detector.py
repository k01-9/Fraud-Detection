# ============================================================
# modules/cookie_detector/detector.py
# Detect cookie manipulation, session hijacking risks,
# insecure cookie configurations, and suspicious attributes
# ============================================================

import re
import logging
from typing import Dict, List, Any

logger = logging.getLogger(__name__)


def parse_cookie_header(cookie_header: str) -> List[Dict[str, Any]]:
    """
    Parse a raw Set-Cookie header string into structured cookie objects.
    Handles both single and multiple cookie definitions.
    """
    cookies = []
    # Split multiple Set-Cookie headers (if newline separated)
    raw_cookies = [c.strip() for c in re.split(r"\r?\n", cookie_header) if c.strip()]

    for raw in raw_cookies:
        cookie = {
            "raw": raw,
            "name": "",
            "value": "",
            "flags": [],
            "attributes": {},
        }
        parts = [p.strip() for p in raw.split(";")]
        if not parts:
            continue

        # First part is name=value
        name_value = parts[0].split("=", 1)
        cookie["name"] = name_value[0].strip()
        cookie["value"] = name_value[1].strip() if len(name_value) > 1 else ""

        # Remaining parts are flags/attributes
        for part in parts[1:]:
            part_lower = part.lower()
            if "=" in part:
                key, val = part.split("=", 1)
                cookie["attributes"][key.strip().lower()] = val.strip()
            else:
                cookie["flags"].append(part.strip())

        cookies.append(cookie)

    return cookies


def detect_cookie_manipulation(cookie_header: str) -> Dict[str, Any]:
    """
    Analyse cookies for:
    - Missing security flags (HttpOnly, Secure, SameSite)
    - Session fixation patterns
    - Suspicious cookie names
    - Overly long expiry
    - Suspicious values (base64 blobs, JWT-like tokens)
    - Potential session hijacking
    """
    if not cookie_header or not cookie_header.strip():
        return {
            "risk_score": 0,
            "risk_flags": [],
            "cookies_analyzed": 0,
            "explanation": "No cookie data provided.",
            "recommendation": "Allow",
        }

    cookies = parse_cookie_header(cookie_header)
    if not cookies:
        return {
            "risk_score": 5,
            "risk_flags": ["Could not parse cookie header"],
            "cookies_analyzed": 0,
            "explanation": "Cookie header could not be parsed.",
            "recommendation": "Inspect manually",
        }

    risk_flags = []
    risk_score = 0

    # Suspicious cookie names that typically hold sensitive session data
    SENSITIVE_NAMES = {
        "session", "sessionid", "sess", "auth", "token", "authtoken",
        "jwt", "bearer", "access_token", "refresh_token", "user", "userid",
        "account", "login", "identity", "csrftoken", "xsrf",
    }

    for cookie in cookies:
        name_lower = cookie["name"].lower()
        flags_lower = [f.lower() for f in cookie["flags"]]
        attrs = cookie["attributes"]

        is_sensitive = any(s in name_lower for s in SENSITIVE_NAMES)

        # ── Missing HttpOnly ──────────────────────────────────
        if is_sensitive and "httponly" not in flags_lower:
            risk_flags.append(
                f"Cookie '{cookie['name']}' is missing HttpOnly flag "
                f"(vulnerable to XSS cookie theft)"
            )
            risk_score += 20

        # ── Missing Secure flag ───────────────────────────────
        if is_sensitive and "secure" not in flags_lower:
            risk_flags.append(
                f"Cookie '{cookie['name']}' is missing Secure flag "
                f"(transmitted over HTTP — interception risk)"
            )
            risk_score += 20

        # ── Missing SameSite ─────────────────────────────────
        if is_sensitive and "samesite" not in attrs:
            risk_flags.append(
                f"Cookie '{cookie['name']}' is missing SameSite attribute "
                f"(CSRF attack surface)"
            )
            risk_score += 15

        # ── SameSite=None without Secure ─────────────────────
        if attrs.get("samesite", "").lower() == "none" and "secure" not in flags_lower:
            risk_flags.append(
                f"Cookie '{cookie['name']}' has SameSite=None but no Secure flag "
                f"(invalid and rejected by modern browsers)"
            )
            risk_score += 10

        # ── Excessively long Max-Age / Expires ────────────────
        if "max-age" in attrs:
            try:
                max_age_days = int(attrs["max-age"]) / 86400
                if max_age_days > 365:
                    risk_flags.append(
                        f"Cookie '{cookie['name']}' has extreme Max-Age "
                        f"({max_age_days:.0f} days — session tokens should not persist this long)"
                    )
                    risk_score += 10
            except ValueError:
                pass

        # ── JWT-like or suspiciously long value ──────────────
        val = cookie["value"]
        if re.match(r"eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}", val):
            risk_flags.append(
                f"Cookie '{cookie['name']}' contains a JWT token "
                f"(storing JWTs in cookies without HttpOnly is dangerous)"
            )
            risk_score += 15 if "httponly" not in flags_lower else 0

        if len(val) > 4096:
            risk_flags.append(
                f"Cookie '{cookie['name']}' has an abnormally large value "
                f"({len(val)} chars — possible data exfiltration or cookie overflow attack)"
            )
            risk_score += 25

        # ── Session fixation: static predictable value ────────
        if is_sensitive and re.match(r"^[a-f0-9]{8,16}$", val):
            risk_flags.append(
                f"Cookie '{cookie['name']}' has a short predictable hex value "
                f"(potential session fixation vulnerability)"
            )
            risk_score += 15

        # ── Domain=. (wildcard) ───────────────────────────────
        domain = attrs.get("domain", "")
        if domain.startswith("."):
            risk_flags.append(
                f"Cookie '{cookie['name']}' has wildcard Domain='{domain}' "
                f"(accessible across all subdomains — increases attack surface)"
            )
            risk_score += 10

    risk_score = min(risk_score, 100)

    if risk_score >= 60:
        recommendation = "BLOCK — Serious cookie security issues detected"
    elif risk_score >= 30:
        recommendation = "WARN — Cookie configuration has security weaknesses"
    elif risk_score > 0:
        recommendation = "MONITOR — Minor cookie configuration issues found"
    else:
        recommendation = "ALLOW — Cookie configuration appears secure"

    if risk_score >= 60:
        explanation = (
            f"HIGH RISK: {len(risk_flags)} security issue(s) detected in cookies. "
            "Session tokens may be vulnerable to theft or manipulation."
        )
    elif risk_flags:
        explanation = (
            f"Cookie configuration has {len(risk_flags)} security gap(s). "
            "These could be exploited for XSS, CSRF, or session hijacking attacks."
        )
    else:
        explanation = "All analyzed cookies appear to have proper security attributes."

    return {
        "risk_score": round(risk_score, 2),
        "risk_flags": risk_flags,
        "cookies_analyzed": len(cookies),
        "cookie_details": [
            {
                "name": c["name"],
                "flags": c["flags"],
                "attributes": c["attributes"],
            }
            for c in cookies
        ],
        "explanation": explanation,
        "recommendation": recommendation,
    }
