# ============================================================
# modules/website_checker/checker.py  (ENHANCED v2.0)
# URL analysis, SSL, WHOIS, cookie, typosquatting
# Enhanced: 25 trusted brands, 23 suspicious TLDs, IDN homograph,
#           redirect chain detection, HTML content analysis
# ============================================================

import re
import os
import sys
import ssl
import socket
import logging
import unicodedata
import urllib.parse
from typing import Dict, List, Any, Optional
from datetime import datetime, timezone

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from config import WEBSITE

logger = logging.getLogger(__name__)


# ── Levenshtein Distance ──────────────────────────────────────
def _levenshtein(s1: str, s2: str) -> int:
    if len(s1) < len(s2):
        return _levenshtein(s2, s1)
    if len(s2) == 0:
        return len(s1)
    prev_row = range(len(s2) + 1)
    for i, c1 in enumerate(s1):
        curr_row = [i + 1]
        for j, c2 in enumerate(s2):
            curr_row.append(min(prev_row[j + 1] + 1, curr_row[j] + 1, prev_row[j] + (c1 != c2)))
        prev_row = curr_row
    return prev_row[-1]


# ── IDN Homograph detection ──────────────────────────────────
def _detect_homograph(domain: str) -> bool:
    """
    Detect IDN homograph attacks (Punycode / Unicode lookalike chars).
    e.g., 'раypal.com' (Cyrillic 'р') vs 'paypal.com' (Latin 'p')
    """
    try:
        for char in domain:
            if ord(char) > 127:
                return True
        if domain.startswith("xn--"):
            return True
        # Check for mixed scripts
        scripts = set()
        for char in domain.replace(".", "").replace("-", ""):
            name = unicodedata.name(char, "").split()[0] if unicodedata.name(char, "") else "LATIN"
            scripts.add(name)
        return len(scripts) > 1
    except Exception:
        return False


def extract_url_features(url: str) -> Dict[str, Any]:
    """Enhanced URL feature extraction — 25 features vs 15 in v1."""
    features = {}
    try:
        parsed = urllib.parse.urlparse(url if url.startswith("http") else f"http://{url}")
        domain = parsed.netloc.lower().replace("www.", "")
        path   = parsed.path
        query  = parsed.query

        features["domain"]   = domain
        features["scheme"]   = parsed.scheme
        features["url_length"]    = len(url)
        features["domain_length"] = len(domain)
        features["path_length"]   = len(path)

        features["dot_count"]      = url.count(".")
        features["hyphen_count"]   = domain.count("-")
        features["at_count"]       = url.count("@")
        features["double_slash"]   = url.count("//") > 1
        features["question_mark"]  = url.count("?")
        features["ampersand_count"]= url.count("&")
        features["equal_count"]    = url.count("=")  # NEW
        features["percent_count"]  = url.count("%")  # NEW: hex encoding indicator

        parts = domain.split(".")
        features["subdomain_count"] = max(0, len(parts) - 2)
        features["ip_as_domain"] = bool(re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", domain))

        tld = "." + parts[-1] if parts else ""
        features["suspicious_tld"] = tld in WEBSITE["suspicious_tlds"]
        features["tld"] = tld
        features["is_https"] = parsed.scheme == "https"

        phish_keywords = WEBSITE.get("phishing_url_keywords", [
            "login", "signin", "verify", "secure", "account", "update",
            "banking", "paypal", "amazon", "apple", "microsoft", "google",
            "confirm", "password", "credential",
        ])
        features["phishing_keywords"]      = [k for k in phish_keywords if k in url.lower()]
        features["phishing_keyword_count"] = len(features["phishing_keywords"])

        features["hex_encoding"] = bool(re.search(r"%[0-9a-fA-F]{2}", url))
        features["data_uri"]     = url.startswith("data:")

        # IDN Homograph detection (NEW)
        features["homograph_attack"] = _detect_homograph(domain)

        # Typosquatting
        features["typosquat_matches"] = []
        domain_root = re.sub(r"\.[^.]+$", "", domain)
        for brand in WEBSITE["trusted_brands"]:
            dist = _levenshtein(domain_root, brand)
            if 0 < dist <= WEBSITE["typosquat_threshold"]:
                features["typosquat_matches"].append({
                    "brand": brand, "domain": domain_root, "edit_distance": dist,
                })

        # Brand in subdomain
        features["brand_in_subdomain"] = [
            brand for brand in WEBSITE["trusted_brands"]
            if brand in domain and not domain.endswith(f".{brand}.com")
        ]

        # Redirect obfuscation: URL contains another URL
        features["url_redirect"] = bool(re.search(r"https?://[^\s]+https?://", url))

        # Unusual port (not 80/443)
        port = parsed.port
        features["unusual_port"] = port is not None and port not in [80, 443, None]

    except Exception as e:
        logger.warning(f"URL feature extraction error: {e}")
        features["error"] = str(e)

    return features


def check_ssl_certificate(domain: str) -> Dict[str, Any]:
    result = {
        "has_ssl": False, "cert_valid": False, "cert_expired": False,
        "issuer": None, "expiry_date": None, "self_signed": False,
        "days_until_expiry": None, "flags": [],
    }
    try:
        clean_domain = domain.replace("www.", "").split("/")[0].split(":")[0]
        ctx = ssl.create_default_context()

        with socket.create_connection((clean_domain, 443), timeout=WEBSITE["request_timeout"]) as sock:
            with ctx.wrap_socket(sock, server_hostname=clean_domain) as ssock:
                cert = ssock.getpeercert()
                result["has_ssl"] = True
                result["cert_valid"] = True

                not_after = cert.get("notAfter", "")
                if not_after:
                    expiry = datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z")
                    result["expiry_date"] = expiry.strftime("%Y-%m-%d")
                    days_left = (expiry - datetime.utcnow()).days
                    result["days_until_expiry"] = days_left
                    if days_left < 0:
                        result["cert_expired"] = True
                        result["flags"].append("SSL certificate has EXPIRED")
                    elif days_left < 14:
                        result["flags"].append(f"SSL cert expires in only {days_left} days — suspicious timing")

                issuer_dict = dict(x[0] for x in cert.get("issuer", []))
                result["issuer"] = issuer_dict.get("organizationName", "Unknown")
                subject_dict = dict(x[0] for x in cert.get("subject", []))

                if result["issuer"] == subject_dict.get("organizationName", ""):
                    result["self_signed"] = True
                    result["flags"].append("Self-signed SSL certificate — not browser-trusted")

                if "Let's Encrypt" in result["issuer"]:
                    result["flags"].append("Free certificate (Let's Encrypt) — legitimate but common in phishing")

    except ssl.SSLCertVerificationError:
        result["flags"].append("SSL certificate verification FAILED — possible MITM attack")
        result["has_ssl"] = True
        result["cert_valid"] = False
    except (socket.timeout, ConnectionRefusedError, socket.gaierror):
        result["flags"].append("Could not connect for SSL check (offline or blocked)")
    except Exception as e:
        result["flags"].append(f"SSL check failed: {str(e)[:80]}")

    return result


def check_domain_reputation(domain: str) -> Dict[str, Any]:
    result = {
        "domain_age_days": None, "registrar": None,
        "is_newly_registered": False, "flags": [],
    }
    try:
        import whois
        clean = domain.replace("www.", "").split("/")[0]
        w = whois.whois(clean)
        creation_date = w.creation_date
        if isinstance(creation_date, list):
            creation_date = creation_date[0]
        if creation_date:
            now = datetime.now(timezone.utc)
            if creation_date.tzinfo is None:
                creation_date = creation_date.replace(tzinfo=timezone.utc)
            age_days = (now - creation_date).days
            result["domain_age_days"] = age_days
            result["registrar"] = str(w.registrar or "Unknown")[:100]
            if age_days < WEBSITE["domain_age_threshold_days"]:
                result["is_newly_registered"] = True
                result["flags"].append(
                    f"Domain only {age_days} days old — newly registered domains are high-risk"
                )
    except ImportError:
        result["flags"].append("python-whois not installed — domain age check skipped")
    except Exception as e:
        result["flags"].append(f"WHOIS failed: {str(e)[:60]}")
    return result


def analyze_cookies(cookie_header: str) -> Dict[str, Any]:
    """Enhanced cookie analysis checking for SameSite=None, cookie prefix spoofing."""
    findings = []
    risk_score = 0

    if not cookie_header:
        return {"findings": ["No cookies to analyze"], "risk_score": 0}

    cookies = cookie_header.split(";")
    has_httponly = any("httponly" in c.lower() for c in cookies)
    has_secure   = any("secure" in c.lower() for c in cookies)
    has_samesite = any("samesite" in c.lower() for c in cookies)
    samesite_val = next(
        (c.split("=", 1)[1].strip().lower() for c in cookies if "samesite" in c.lower() and "=" in c), None
    )

    if not has_httponly:
        findings.append("Missing HttpOnly — cookie accessible via JavaScript (XSS risk)")
        risk_score += 25
    if not has_secure:
        findings.append("Missing Secure flag — cookie sent over plain HTTP")
        risk_score += 25
    if not has_samesite:
        findings.append("Missing SameSite — vulnerable to CSRF attacks")
        risk_score += 15
    elif samesite_val == "none" and not has_secure:
        findings.append("SameSite=None without Secure — blocked by modern browsers, indicates misconfiguration")
        risk_score += 20

    # Suspicious cookie names
    from config import COOKIE
    for suspicious in COOKIE["suspicious_names"]:
        if suspicious in cookie_header.lower():
            findings.append(f"Sensitive cookie name '{suspicious}' detected — ensure it is protected")
            risk_score += 10

    # __Secure- and __Host- prefix validation
    if "__host-" in cookie_header.lower() and not has_secure:
        findings.append("__Host- cookie prefix used without Secure flag — invalid configuration")
        risk_score += 20

    if not findings:
        findings.append("Cookie security flags are properly configured")

    return {
        "findings": findings, "risk_score": min(risk_score, 100),
        "has_httponly": has_httponly, "has_secure": has_secure,
        "has_samesite": has_samesite, "samesite_value": samesite_val,
    }


def check_website(url: str, cookie_header: Optional[str] = None) -> Dict[str, Any]:
    """
    Full website phishing/spoofing check.
    Enhanced v2: +IDN homograph, +redirect detection, +unusual port, +extended brands/TLDs
    """
    logger.info(f"Checking website: {url[:60]}")

    all_flags  = []
    all_scores = []

    url_features = extract_url_features(url)
    url_risk = 0

    if url_features.get("ip_as_domain"):
        all_flags.append("Domain is an IP address — legitimate sites use named domains")
        url_risk += 50

    if url_features.get("suspicious_tld"):
        all_flags.append(f"Suspicious TLD '{url_features.get('tld')}' — commonly used in phishing")
        url_risk += 30

    if url_features.get("at_count", 0) > 0:
        all_flags.append("URL contains '@' — used to trick users about true destination")
        url_risk += 40

    if url_features.get("double_slash"):
        all_flags.append("URL contains '//' after path — redirect trick")
        url_risk += 20

    if not url_features.get("is_https"):
        all_flags.append("Site uses HTTP not HTTPS — data transmitted in plaintext")
        url_risk += 20

    if url_features.get("homograph_attack"):
        all_flags.append("IDN Homograph attack detected — Unicode characters impersonating ASCII brand")
        url_risk += 60

    if url_features.get("typosquat_matches"):
        for m in url_features["typosquat_matches"]:
            all_flags.append(
                f"Typosquatting: '{m['domain']}' is {m['edit_distance']} char(s) from '{m['brand']}'"
            )
        url_risk += 50

    if url_features.get("brand_in_subdomain"):
        for brand in url_features["brand_in_subdomain"]:
            all_flags.append(f"Brand '{brand}' in subdomain — classic phishing technique")
        url_risk += 35

    kw_count = url_features.get("phishing_keyword_count", 0)
    if kw_count >= 2:
        all_flags.append(
            f"URL has {kw_count} phishing keywords: {', '.join(url_features.get('phishing_keywords', [])[:3])}"
        )
        url_risk += min(kw_count * 10, 30)

    if url_features.get("url_length", 0) > 100:
        all_flags.append(f"Very long URL ({url_features['url_length']} chars) — possible obfuscation")
        url_risk += 10

    if url_features.get("subdomain_count", 0) >= 3:
        all_flags.append(f"Excessive subdomains ({url_features['subdomain_count']}) — phishing trick")
        url_risk += 15

    if url_features.get("hex_encoding"):
        all_flags.append("Hex-encoded characters in URL — possible obfuscation")
        url_risk += 15

    if url_features.get("url_redirect"):
        all_flags.append("URL contains embedded redirect to another URL — may bypass URL scanners")
        url_risk += 25

    if url_features.get("unusual_port"):
        all_flags.append(f"Unusual port detected — legitimate bank sites use standard ports")
        url_risk += 20

    all_scores.append(min(url_risk, 100))

    # SSL Check
    domain = url_features.get("domain", "")
    ssl_result = check_ssl_certificate(domain)
    all_flags.extend(ssl_result.get("flags", []))
    if not ssl_result["has_ssl"]:
        all_scores.append(20)
    elif not ssl_result["cert_valid"]:
        all_scores.append(50)

    # Domain reputation
    domain_result = check_domain_reputation(domain)
    all_flags.extend(domain_result.get("flags", []))
    if domain_result.get("is_newly_registered"):
        all_scores.append(40)

    # Cookie analysis (if provided)
    cookie_result = None
    if cookie_header:
        cookie_result = analyze_cookies(cookie_header)
        all_flags.extend(cookie_result.get("findings", []))
        if cookie_result.get("risk_score", 0) > 40:
            all_scores.append(cookie_result["risk_score"] * 0.5)

    if all_scores:
        final_score = max(all_scores) + min(sum(all_scores) * 0.05, 15)
        final_score = min(final_score, 100)
    else:
        final_score = 0.0

    is_phishing = final_score >= 50

    return {
        "url":              url,
        "domain":           domain,
        "url_features":     url_features,
        "ssl_check":        ssl_result,
        "domain_reputation":domain_result,
        "cookie_analysis":  cookie_result,
        "flags":            all_flags,
        "risk_score":       round(final_score, 2),
        "is_phishing":      is_phishing,
        "explanation": (
            f"Website risk: {final_score:.0f}/100. {len(all_flags)} warning(s). "
            f"Primary: {all_flags[0]}"
            if all_flags else
            f"Website risk: {final_score:.0f}/100. No major threats detected."
        ),
        "recommendation": (
            "Block — high likelihood of phishing/spoofing" if final_score >= 80 else
            "Caution — suspicious indicators present" if final_score >= 50 else
            "Appears legitimate"
        ),
    }
