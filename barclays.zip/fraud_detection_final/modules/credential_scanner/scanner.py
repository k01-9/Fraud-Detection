# ============================================================
# modules/credential_scanner/scanner.py
# Regex + spaCy NER credential exposure detector
# ============================================================

import re
import os
import sys
import logging
from typing import Dict, List, Any

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from config import CREDENTIAL_PATTERNS

logger = logging.getLogger(__name__)

# Lazy-load spaCy to avoid crash if not installed
_nlp = None


def _load_spacy():
    global _nlp
    if _nlp is not None:
        return _nlp
    try:
        import spacy
        try:
            _nlp = spacy.load("en_core_web_sm")
            logger.info("spaCy model loaded successfully.")
        except OSError:
            logger.warning("spaCy 'en_core_web_sm' not found. Run: python -m spacy download en_core_web_sm")
            _nlp = None
    except ImportError:
        logger.warning("spaCy not installed. NER-based detection disabled.")
        _nlp = None
    return _nlp


def _anonymize_credential(cred_type: str, value: str) -> str:
    """Return a partially masked version for logging (never store raw credentials)."""
    if len(value) <= 6:
        return "*" * len(value)
    visible = min(4, len(value) // 4)
    return value[:visible] + "*" * (len(value) - visible * 2) + value[-visible:]


def scan_with_regex(text: str) -> List[Dict[str, Any]]:
    """
    Scan text for credential patterns using regex.
    Returns list of findings with anonymized values.
    """
    findings = []

    for cred_type, pattern in CREDENTIAL_PATTERNS.items():
        matches = re.finditer(pattern, text, re.IGNORECASE | re.MULTILINE)
        for match in matches:
            full_match = match.group(0)
            # Extract the actual credential value (group 2 if capture group exists)
            try:
                value = match.group(2) if match.lastindex and match.lastindex >= 2 else full_match
            except IndexError:
                value = full_match

            # Severity mapping
            severity = _get_severity(cred_type)

            findings.append({
                "type": cred_type,
                "pattern": pattern[:30] + "...",  # Don't expose full pattern in output
                "value_masked": _anonymize_credential(cred_type, value),
                "position": match.start(),
                "severity": severity,
                "risk_score": _severity_to_score(severity),
            })

    return findings


def scan_with_ner(text: str) -> List[Dict[str, Any]]:
    """
    Use spaCy NER to detect person names, organizations, locations.
    These can constitute PII exposure in leaked documents.
    """
    findings = []
    nlp = _load_spacy()

    if nlp is None:
        return findings

    try:
        # Limit text length for performance
        doc = nlp(text[:50000])

        entity_counts = {}
        for ent in doc.ents:
            if ent.label_ in ["PERSON", "ORG", "GPE", "LOC", "MONEY", "CARDINAL"]:
                key = ent.label_
                entity_counts[key] = entity_counts.get(key, 0) + 1

        for entity_type, count in entity_counts.items():
            if count > 0:
                findings.append({
                    "type": f"NER_{entity_type}",
                    "description": f"Detected {count} {entity_type} entities (potential PII)",
                    "count": count,
                    "severity": "LOW" if entity_type not in ["PERSON", "MONEY"] else "MEDIUM",
                    "risk_score": 20 if entity_type not in ["PERSON", "MONEY"] else 40,
                })

    except Exception as e:
        logger.warning(f"NER scan failed: {e}")

    return findings


def _get_severity(cred_type: str) -> str:
    """Map credential type to severity level."""
    critical = ["Credit Card", "Private Key Header", "AWS Secret Key", "GitHub Token",
                "Google API Key", "JWT Token", "Password in text"]
    high = ["AWS Access Key", "GitHub OAuth", "Slack Token", "Generic API Key", "Basic Auth (base64)"]
    medium = ["Email Address", "Phone Number"]
    low = ["IPv4 Address"]

    if cred_type in critical:
        return "CRITICAL"
    elif cred_type in high:
        return "HIGH"
    elif cred_type in medium:
        return "MEDIUM"
    return "LOW"


def _severity_to_score(severity: str) -> float:
    mapping = {"CRITICAL": 90, "HIGH": 70, "MEDIUM": 45, "LOW": 20}
    return mapping.get(severity, 20)


def scan_file_for_credentials(file_path: str) -> Dict[str, Any]:
    """Scan a file for exposed credentials."""
    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            text = f.read()
        return scan_text_for_credentials(text, source=os.path.basename(file_path))
    except Exception as e:
        return {"error": str(e), "findings": [], "risk_score": 0}


def scan_text_for_credentials(text: str, source: str = "input") -> Dict[str, Any]:
    """
    Main credential scanning function.

    Args:
        text: The text content to scan
        source: Label for where this text came from (for logging, not raw data)

    Returns:
        {
            "findings": list of detected credentials (anonymized),
            "total_found": int,
            "highest_severity": str,
            "risk_score": float (0–100),
            "ner_findings": list,
            "explanation": str,
            "recommendations": list[str]
        }
    """
    if not text or not text.strip():
        return {
            "findings": [],
            "total_found": 0,
            "highest_severity": "SAFE",
            "risk_score": 0.0,
            "ner_findings": [],
            "explanation": "No content to scan.",
            "recommendations": [],
        }

    # ── Regex scan ────────────────────────────────────────────
    regex_findings = scan_with_regex(text)

    # ── NER scan ─────────────────────────────────────────────
    ner_findings = scan_with_ner(text)

    # ── Risk scoring ──────────────────────────────────────────
    all_findings = regex_findings + ner_findings
    total = len(regex_findings)  # NER findings are informational

    if total == 0:
        risk_score = 0.0
        highest_severity = "SAFE"
    else:
        scores = [f["risk_score"] for f in regex_findings]
        # Use max score + bonus for multiple findings
        risk_score = min(max(scores) + (len(scores) - 1) * 5, 100)
        severities = [f["severity"] for f in regex_findings]
        severity_order = ["LOW", "MEDIUM", "HIGH", "CRITICAL"]
        highest_severity = max(severities, key=lambda s: severity_order.index(s) if s in severity_order else -1)

    # ── Build explanation ─────────────────────────────────────
    if total == 0:
        explanation = "No credential exposure detected."
        recommendations = []
    else:
        types_found = list(set(f["type"] for f in regex_findings))
        explanation = (
            f"Found {total} potential credential exposure(s): {', '.join(types_found[:5])}. "
            f"Highest severity: {highest_severity}."
        )
        recommendations = _build_recommendations(regex_findings)

    logger.info(f"Credential scan ({source}): {total} findings, risk={risk_score:.1f}")

    return {
        "findings": regex_findings,
        "total_found": total,
        "highest_severity": highest_severity,
        "risk_score": round(risk_score, 2),
        "ner_findings": ner_findings,
        "explanation": explanation,
        "recommendations": recommendations,
    }


def _build_recommendations(findings: List[Dict]) -> List[str]:
    """Generate actionable recommendations based on findings."""
    recs = []
    types = set(f["type"] for f in findings)

    if "Credit Card" in types:
        recs.append("Immediately invalidate exposed credit card numbers and notify the card issuer.")
    if any("Key" in t or "Token" in t for t in types):
        recs.append("Rotate all exposed API keys and tokens immediately.")
    if "Password in text" in types:
        recs.append("Change all exposed passwords immediately and enable MFA.")
    if "Private Key Header" in types:
        recs.append("Revoke and regenerate the exposed private key immediately.")
    if "JWT Token" in types:
        recs.append("Invalidate exposed JWT tokens and review authentication logs.")
    if "Email Address" in types:
        recs.append("Review email exposure — may enable targeted phishing attacks.")

    if not recs:
        recs.append("Review and remove sensitive data from this content before sharing.")

    return recs
