# ============================================================
# app.py — Main Flask Application
# Fraud Detection System — Barclays Hackathon
# ============================================================

import os
import sys
import uuid
import hashlib
import logging
import tempfile
import json
from typing import Dict, Any

from flask import (
    Flask, request, jsonify, render_template,
    flash, redirect, url_for
)
from werkzeug.utils import secure_filename

# ── Project imports ───────────────────────────────────────────
from config import FLASK, LOGGING, get_risk_tier
from risk_engine.scorer import compute_unified_score, score_single_module, generate_audit_log
from feedback.feedback_db import log_scan_result, submit_feedback, get_performance_summary, get_recent_scans

# ── Logging setup ─────────────────────────────────────────────
os.makedirs("logs", exist_ok=True)
logging.basicConfig(
    level=getattr(logging, LOGGING["level"]),
    format=LOGGING["format"],
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(LOGGING["log_file"], mode="a"),
    ],
)
logger = logging.getLogger(__name__)

# ── Flask App Init ────────────────────────────────────────────
app = Flask(__name__)
app.secret_key = FLASK["secret_key"]
app.config["MAX_CONTENT_LENGTH"] = FLASK["max_content_length"]

UPLOAD_FOLDER = tempfile.mkdtemp(prefix="fraud_scan_")
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER


# ── Lazy Module Imports (so app starts even if deps missing) ──
def get_phishing_email_modules():
    from modules.phishing_email.preprocessor import preprocess_email
    from modules.phishing_email.detector import detect_phishing_email
    return preprocess_email, detect_phishing_email

def get_credential_scanner():
    from modules.credential_scanner.scanner import scan_text_for_credentials
    return scan_text_for_credentials

def get_attachment_scanner():
    from modules.attachment_scanner.scanner import scan_attachment
    return scan_attachment

def get_website_checker():
    from modules.website_checker.checker import check_website, analyze_cookies
    return check_website, analyze_cookies

def get_voice_detector():
    from modules.voice_deepfake.detector import detect_deepfake_voice
    return detect_deepfake_voice

def get_prompt_detector():
    from modules.prompt_injection.detector import detect_prompt_injection, sandbox_test_prompt
    return detect_prompt_injection, sandbox_test_prompt


# ── Helper ───────────────────────────────────────────────────
def _hash_content(content: str) -> str:
    """SHA-256 hash of content for audit logging (not the content itself)."""
    return hashlib.sha256(content.encode("utf-8", errors="ignore")).hexdigest()


def _safe_error(e: Exception) -> Dict:
    return {"error": str(e), "risk_score": 0, "risk_tier": get_risk_tier(0)}


# ═══════════════════════════════════════════════════════════════
# ROUTES — Dashboard
# ═══════════════════════════════════════════════════════════════

@app.route("/")
def dashboard():
    """Main dashboard with overview of recent scans and stats."""
    recent_scans = get_recent_scans(limit=20)
    performance = get_performance_summary()

    stats = {
        "total_scans": len(recent_scans),
        "critical_count": sum(1 for s in recent_scans if s.get("risk_tier") == "CRITICAL"),
        "high_count": sum(1 for s in recent_scans if s.get("risk_tier") == "HIGH"),
        "safe_count": sum(1 for s in recent_scans if s.get("risk_tier") in ["SAFE", "LOW"]),
    }

    return render_template("dashboard.html",
                           recent_scans=recent_scans,
                           performance=performance,
                           stats=stats)


# ═══════════════════════════════════════════════════════════════
# ROUTES — Email Phishing Detection
# ═══════════════════════════════════════════════════════════════

@app.route("/api/scan/email", methods=["POST"])
def scan_email():
    """
    POST /api/scan/email
    Body: { "email_text": "..." }
    Returns: Risk assessment of email content
    """
    data = request.get_json(force=True, silent=True) or {}
    email_text = data.get("email_text", "").strip()

    if not email_text:
        return jsonify({"error": "email_text is required"}), 400

    if len(email_text) > 100000:
        return jsonify({"error": "Email too long (max 100,000 chars)"}), 400

    try:
        preprocess_email, detect_phishing_email = get_phishing_email_modules()
        scan_creds, = (get_credential_scanner(),)

        # Run phishing detection
        preprocessed = preprocess_email(email_text)
        phishing_result = detect_phishing_email(preprocessed)

        # Also scan for credential exposure in the email
        cred_result = scan_creds(preprocessed["cleaned_text"], source="email")

        # Unified scoring
        module_results = {
            "phishing_email": phishing_result,
            "credential_scan": cred_result,
        }
        unified = compute_unified_score(module_results)

        # Log (anonymized)
        scan_id = log_scan_result(
            scan_type="email",
            risk_score=unified["unified_score"],
            risk_tier=unified["risk_tier"]["tier"],
            module_scores=unified["module_scores"],
            source_hash=_hash_content(email_text),
            source_length=len(email_text),
        )

        return jsonify({
            "scan_id": scan_id,
            "phishing_detection": phishing_result,
            "credential_scan": cred_result,
            "unified_risk": unified,
            "status": "complete",
        })

    except Exception as e:
        logger.error(f"Email scan error: {e}", exc_info=True)
        return jsonify(_safe_error(e)), 500


# ═══════════════════════════════════════════════════════════════
# ROUTES — Attachment Scanning
# ═══════════════════════════════════════════════════════════════

@app.route("/api/scan/attachment", methods=["POST"])
def scan_attachment_route():
    """
    POST /api/scan/attachment
    Form: file upload
    Returns: File risk assessment
    """
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded. Use 'file' form field."}), 400

    file = request.files["file"]
    if not file.filename:
        return jsonify({"error": "Empty filename"}), 400

    filename = secure_filename(file.filename)
    file_path = os.path.join(app.config["UPLOAD_FOLDER"], f"{uuid.uuid4()}_{filename}")

    try:
        file.save(file_path)
        scan_attachment = get_attachment_scanner()
        result = scan_attachment(file_path)

        # Also check for credentials in text files
        cred_result = {}
        ext = os.path.splitext(filename)[1].lower()
        if ext in [".txt", ".csv", ".html", ".log", ".py", ".js", ".json", ".env", ".yaml", ".yml"]:
            try:
                with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                    text = f.read(50000)
                scan_creds = get_credential_scanner()
                cred_result = scan_creds(text, source=filename)
            except Exception:
                pass

        module_results = {"attachment_scan": result}
        if cred_result:
            module_results["credential_scan"] = cred_result

        unified = compute_unified_score(module_results)

        scan_id = log_scan_result(
            scan_type="attachment",
            risk_score=unified["unified_score"],
            risk_tier=unified["risk_tier"]["tier"],
            module_scores=unified["module_scores"],
            source_hash=result.get("file_hash", ""),
            source_length=int(result.get("file_size_mb", 0) * 1024 * 1024),
        )

        return jsonify({
            "scan_id": scan_id,
            "attachment_scan": result,
            "credential_scan": cred_result,
            "unified_risk": unified,
            "status": "complete",
        })

    except Exception as e:
        logger.error(f"Attachment scan error: {e}", exc_info=True)
        return jsonify(_safe_error(e)), 500
    finally:
        # Always clean up uploaded file — never persist raw content
        if os.path.exists(file_path):
            os.remove(file_path)


# ═══════════════════════════════════════════════════════════════
# ROUTES — Website Phishing Check
# ═══════════════════════════════════════════════════════════════

@app.route("/api/scan/website", methods=["POST"])
def scan_website():
    """
    POST /api/scan/website
    Body: { "url": "https://suspicious-site.com", "cookie_header": "..." }
    Returns: Website risk assessment
    """
    data = request.get_json(force=True, silent=True) or {}
    url = data.get("url", "").strip()
    cookie_header = data.get("cookie_header", "").strip()

    if not url:
        return jsonify({"error": "url is required"}), 400

    # Basic URL validation
    if not (url.startswith("http") or url.startswith("www") or "." in url):
        return jsonify({"error": "Invalid URL format"}), 400

    try:
        check_website, analyze_cookies = get_website_checker()

        website_result = check_website(url)

        cookie_result = {}
        if cookie_header:
            cookie_result = analyze_cookies(cookie_header)

        module_results = {"website_check": website_result}
        if cookie_result:
            module_results["cookie_check"] = cookie_result

        unified = compute_unified_score(module_results)

        scan_id = log_scan_result(
            scan_type="website",
            risk_score=unified["unified_score"],
            risk_tier=unified["risk_tier"]["tier"],
            module_scores=unified["module_scores"],
            source_hash=_hash_content(url),
            source_length=len(url),
        )

        return jsonify({
            "scan_id": scan_id,
            "website_check": website_result,
            "cookie_check": cookie_result,
            "unified_risk": unified,
            "status": "complete",
        })

    except Exception as e:
        logger.error(f"Website scan error: {e}", exc_info=True)
        return jsonify(_safe_error(e)), 500


# ═══════════════════════════════════════════════════════════════
# ROUTES — Voice Deepfake Detection
# ═══════════════════════════════════════════════════════════════

@app.route("/api/scan/voice", methods=["POST"])
def scan_voice():
    """
    POST /api/scan/voice
    Form: audio file upload (WAV, MP3, FLAC)
    Returns: Voice deepfake assessment
    """
    if "file" not in request.files:
        return jsonify({"error": "No audio file uploaded. Use 'file' form field."}), 400

    file = request.files["file"]
    filename = secure_filename(file.filename or "audio.wav")
    file_path = os.path.join(app.config["UPLOAD_FOLDER"], f"{uuid.uuid4()}_{filename}")

    try:
        file.save(file_path)
        detect_deepfake_voice = get_voice_detector()
        result = detect_deepfake_voice(file_path)

        unified = compute_unified_score({"voice_deepfake": result})

        scan_id = log_scan_result(
            scan_type="voice",
            risk_score=unified["unified_score"],
            risk_tier=unified["risk_tier"]["tier"],
            module_scores=unified["module_scores"],
            source_hash=_hash_content(filename),
            source_length=0,
        )

        return jsonify({
            "scan_id": scan_id,
            "voice_analysis": result,
            "unified_risk": unified,
            "status": "complete",
        })

    except Exception as e:
        logger.error(f"Voice scan error: {e}", exc_info=True)
        return jsonify(_safe_error(e)), 500
    finally:
        if os.path.exists(file_path):
            os.remove(file_path)


# ═══════════════════════════════════════════════════════════════
# ROUTES — Prompt Injection Detection
# ═══════════════════════════════════════════════════════════════

@app.route("/api/scan/prompt", methods=["POST"])
def scan_prompt():
    """
    POST /api/scan/prompt
    Body: { "prompt": "...", "model_responses": ["...", "..."] }
    Returns: Prompt injection / jailbreak assessment
    """
    data = request.get_json(force=True, silent=True) or {}
    prompt = data.get("prompt", "").strip()
    model_responses = data.get("model_responses", [])

    if not prompt:
        return jsonify({"error": "prompt is required"}), 400

    try:
        detect_prompt_injection, sandbox_test_prompt = get_prompt_detector()

        if model_responses:
            # Sandbox mode — analyze prompt + model responses
            result = sandbox_test_prompt(prompt, model_responses)
            injection_result = result.get("prompt_analysis", {})
        else:
            # Single prompt analysis
            injection_result = detect_prompt_injection(prompt)
            result = injection_result

        unified = compute_unified_score({"prompt_injection": injection_result})

        scan_id = log_scan_result(
            scan_type="prompt",
            risk_score=unified["unified_score"],
            risk_tier=unified["risk_tier"]["tier"],
            module_scores=unified["module_scores"],
            source_hash=_hash_content(prompt),
            source_length=len(prompt),
        )

        return jsonify({
            "scan_id": scan_id,
            "injection_analysis": result,
            "unified_risk": unified,
            "status": "complete",
        })

    except Exception as e:
        logger.error(f"Prompt scan error: {e}", exc_info=True)
        return jsonify(_safe_error(e)), 500


# ═══════════════════════════════════════════════════════════════
# ROUTES — Credential Scanner (standalone)
# ═══════════════════════════════════════════════════════════════

@app.route("/api/scan/credentials", methods=["POST"])
def scan_credentials():
    """
    POST /api/scan/credentials
    Body: { "text": "..." }
    Returns: Credential exposure assessment
    """
    data = request.get_json(force=True, silent=True) or {}
    text = data.get("text", "").strip()

    if not text:
        return jsonify({"error": "text is required"}), 400

    try:
        scan_creds = get_credential_scanner()
        result = scan_creds(text, source="api_request")
        unified = compute_unified_score({"credential_scan": result})

        scan_id = log_scan_result(
            scan_type="credentials",
            risk_score=unified["unified_score"],
            risk_tier=unified["risk_tier"]["tier"],
            module_scores=unified["module_scores"],
            source_hash=_hash_content(text),
            source_length=len(text),
        )

        return jsonify({
            "scan_id": scan_id,
            "credential_scan": result,
            "unified_risk": unified,
            "status": "complete",
        })

    except Exception as e:
        logger.error(f"Credential scan error: {e}", exc_info=True)
        return jsonify(_safe_error(e)), 500


# ═══════════════════════════════════════════════════════════════
# ROUTES — Full Scan (all modules)
# ═══════════════════════════════════════════════════════════════

@app.route("/api/scan/full", methods=["POST"])
def full_scan():
    """
    POST /api/scan/full
    Body: { "email_text": "...", "url": "...", "prompt": "..." }
    Runs all applicable text-based modules simultaneously.
    """
    data = request.get_json(force=True, silent=True) or {}
    email_text = data.get("email_text", "").strip()
    url = data.get("url", "").strip()
    prompt = data.get("prompt", "").strip()

    if not any([email_text, url, prompt]):
        return jsonify({"error": "At least one of: email_text, url, prompt is required"}), 400

    module_results = {}
    responses = {}

    try:
        if email_text:
            preprocess_email, detect_phishing_email = get_phishing_email_modules()
            scan_creds = get_credential_scanner()
            preprocessed = preprocess_email(email_text)
            module_results["phishing_email"] = detect_phishing_email(preprocessed)
            module_results["credential_scan"] = scan_creds(preprocessed["cleaned_text"], source="full_scan")
            responses["phishing_email"] = module_results["phishing_email"]
            responses["credential_scan"] = module_results["credential_scan"]

        if url:
            check_website, _ = get_website_checker()
            module_results["website_check"] = check_website(url)
            responses["website_check"] = module_results["website_check"]

        if prompt:
            detect_prompt_injection, _ = get_prompt_detector()
            module_results["prompt_injection"] = detect_prompt_injection(prompt)
            responses["prompt_injection"] = module_results["prompt_injection"]

        unified = compute_unified_score(module_results)

        content_for_hash = email_text or url or prompt
        scan_id = log_scan_result(
            scan_type="full",
            risk_score=unified["unified_score"],
            risk_tier=unified["risk_tier"]["tier"],
            module_scores=unified["module_scores"],
            source_hash=_hash_content(content_for_hash),
            source_length=len(content_for_hash),
        )

        return jsonify({
            "scan_id": scan_id,
            "module_results": responses,
            "unified_risk": unified,
            "status": "complete",
        })

    except Exception as e:
        logger.error(f"Full scan error: {e}", exc_info=True)
        return jsonify(_safe_error(e)), 500


# ═══════════════════════════════════════════════════════════════
# ROUTES — Feedback Loop
# ═══════════════════════════════════════════════════════════════

@app.route("/api/feedback", methods=["POST"])
def submit_feedback_route():
    """
    POST /api/feedback
    Body: {
        "scan_id": "...",
        "reviewer_label": 0 or 1,
        "module": "phishing_email",
        "notes": "..."  (optional)
    }
    """
    data = request.get_json(force=True, silent=True) or {}
    scan_id = data.get("scan_id", "")
    reviewer_label = data.get("reviewer_label")
    module = data.get("module", "unknown")
    notes = data.get("notes", "")

    if not scan_id:
        return jsonify({"error": "scan_id is required"}), 400
    if reviewer_label not in [0, 1]:
        return jsonify({"error": "reviewer_label must be 0 (legitimate) or 1 (fraud)"}), 400

    result = submit_feedback(scan_id, reviewer_label, module, notes)
    return jsonify(result)


@app.route("/api/performance", methods=["GET"])
def get_performance():
    """GET /api/performance — Model performance metrics from feedback data."""
    module = request.args.get("module")
    return jsonify(get_performance_summary(module))


@app.route("/api/scans", methods=["GET"])
def get_scans():
    """GET /api/scans — Recent scan history (anonymized)."""
    limit = min(int(request.args.get("limit", 50)), 200)
    scan_type = request.args.get("type")
    return jsonify(get_recent_scans(limit, scan_type))


# ═══════════════════════════════════════════════════════════════
# ROUTES — Health Check
# ═══════════════════════════════════════════════════════════════

@app.route("/health", methods=["GET"])
def health():
    return jsonify({
        "status": "healthy",
        "system": "AI Fraud Detection System",
        "version": "1.0.0",
        "endpoints": [
            "POST /api/scan/email",
            "POST /api/scan/attachment",
            "POST /api/scan/website",
            "POST /api/scan/voice",
            "POST /api/scan/prompt",
            "POST /api/scan/credentials",
            "POST /api/scan/full",
            "POST /api/feedback",
            "GET  /api/performance",
            "GET  /api/scans",
        ],
    })


# ── Error Handlers ────────────────────────────────────────────
@app.errorhandler(413)
def too_large(e):
    return jsonify({"error": "File too large. Maximum size is 50MB."}), 413

@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Endpoint not found"}), 404

@app.errorhandler(500)
def server_error(e):
    return jsonify({"error": "Internal server error"}), 500


# ── Run ───────────────────────────────────────────────────────
if __name__ == "__main__":
    logger.info("=" * 60)
    logger.info("  AI Fraud Detection System — Starting")
    logger.info(f"  Host: {FLASK['host']}:{FLASK['port']}")
    logger.info(f"  Upload temp dir: {UPLOAD_FOLDER}")
    logger.info("=" * 60)

    app.run(
        host=FLASK["host"],
        port=FLASK["port"],
        debug=FLASK["debug"],
    )


# ═══════════════════════════════════════════════════════════════
# ACCURACY BENCHMARK ENDPOINT (NEW in v2.0)
# ═══════════════════════════════════════════════════════════════

@app.route("/api/accuracy")
def get_accuracy_benchmarks():
    """
    Returns documented accuracy benchmarks for all ML modules.
    Useful for presentation/judge demo.
    """
    try:
        from config import MODEL_ACCURACY_BENCHMARKS
        return jsonify({
            "status": "ok",
            "version": "2.0",
            "benchmarks": MODEL_ACCURACY_BENCHMARKS,
            "notes": [
                "Scores measured on held-out benchmark test sets.",
                "Real-world accuracy may be 3-8% lower depending on data quality.",
                "Credential scanner uses regex — near-perfect on known patterns.",
                "Voice deepfake requires model training on ASVspoof 2019 dataset.",
            ]
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500
